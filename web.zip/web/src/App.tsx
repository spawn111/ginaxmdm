import { Router, Routes, Route } from "@solidjs/router";
import Dashboard from "./pages/Dashboard";
import Devices from "./pages/Devices";
import Login from "./pages/Login";
import Settings from "./pages/Settings";
import Users from "./pages/Users";

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" component={Dashboard} />
        <Route path="/devices" component={Devices} />
        <Route path="/login" component={Login} />
        <Route path="/settings" component={Settings} />
        <Route path="/users" component={Users} />
      </Routes>
    </Router>
  );
}
