export default function Footer() {
  return (
    <footer class="footer">
      <p>© 2025 MDM Контроль</p>
    </footer>
  );
}
