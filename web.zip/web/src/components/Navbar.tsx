import { A } from "@solidjs/router";

export default function Navbar() {
  return (
    <nav class="navbar">
      <A href="/">Dashboard</A>
      <A href="/devices">Devices</A>
      <A href="/settings">Settings</A>
      <A href="/users">Users</A>
    </nav>
  );
}
