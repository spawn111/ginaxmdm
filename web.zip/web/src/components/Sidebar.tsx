import { A } from "@solidjs/router";

export default function Sidebar() {
  return (
    <nav class="sidebar">
      <ul>
        <li><A href="/" activeClass="active">📊 Dashboard</A></li>
        <li><A href="/devices" activeClass="active">📱 Devices</A></li>
        <li><A href="/users" activeClass="active">👥 Users</A></li>
        <li><A href="/settings" activeClass="active">⚙️ Settings</A></li>
      </ul>
    </nav>
  );
}
