export default function Dashboard() {
  return (
    <div>
      <h2>Дашбоард</h2>
      <p>Ласкаво просимо до MDM панелі!</p>
    </div>
  );
}
