export default function Devices() {
  return (
    <div>
      <h2>Пристрої</h2>
      <p>Тут Ви можете керувати пристроями.</p>
    </div>
  );
}
