export default function Login() {
  return (
    <div>
      <h2>Логін</h2>
      <p>Буль ласка введіть свої данні.</p>
    </div>
  );
}
