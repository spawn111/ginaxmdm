export default function Settings() {
  return (
    <div>
      <h2>Налаштування</h2>
      <p>Налаштування МДМ панелі.</p>
    </div>
  );
}
