export default function Users() {
  return (
    <div>
      <h2>Користувачі</h2>
      <p>Менеджер користувачів МДМ панелі.</p>
    </div>
  );
}
