import { Route } from "@solidjs/router";
import Dashboard from "./pages/Dashboard";
import Devices from "./pages/Devices";
import Login from "./pages/Login";
import Settings from "./pages/Settings";
import Users from "./pages/Users";

export const routes = [
  { path: "/", component: Dashboard },
  { path: "/devices", component: Devices },
  { path: "/login", component: Login },
  { path: "/settings", component: Settings },
  { path: "/users", component: Users },
];
